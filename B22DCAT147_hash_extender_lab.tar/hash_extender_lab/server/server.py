import socket
import hashlib

HOST = "0.0.0.0"
PORT = 9000

#doc khoa tu file
try:
    with open("key.txt", "r") as f:
        secret_key = f.read().strip()
except FileNotFoundError:
    print("File key.txt khong ton tai.")
    exit(1)

print("== Hash Length Extension Server ==")

# tao socket tcp
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    print(f"Dang lang nghe tren {HOST}:{PORT} ...")

    while True:
        conn, addr = s.accept()
        print(f"Ket noi moi tu {addr}")

        with conn:
            try:
                raw_data = conn.recv(2048)
                print(f"Du lieu raw nhan duoc ({len(raw_data)} bytes)")

                #tach msg va mac
                try:
                    raw_msg, recv_mac = raw_data.split(b"||")
                except ValueError:
                    conn.sendall(b"[!] Loi: Khong tach duoc message va MAC.\n")
                    continue

                print("[DEBUG] Message (hex):", raw_msg.hex())
                print("[DEBUG] Received MAC  :", recv_mac.decode())

                #tinh lai mac
                valid_mac = hashlib.md5((secret_key.encode() + raw_msg)).hexdigest()
                print("[DEBUG] Expected MAC  :", valid_mac)

                response = ""
                if recv_mac.decode() == valid_mac:
                    response += "OK: MAC hop le. Lenh chap nhan.\n"

                    try:
                        decoded_msg = raw_msg.decode('latin1')
                        if "view=private.txt" in decoded_msg:
                            response += "VIEW: Dang doc private.txt...\n"
                            try:
                                with open("private.txt", "r") as f:
                                    response += "--- Noi dung private.txt ---\n"
                                    response += f.read() + "\n"
                            except Exception as e:
                                response += f"Loi khi doc file: {str(e)}\n"
                    except Exception as e:
                        response += f"Loi khi xu ly message: {str(e)}\n"
                else:
                    response += "FAIL: MAC khong hop le. Lenh bi tu choi.\n"

                conn.sendall(response.encode())

            except Exception as e:
                conn.sendall(f"ERROR: Loi xay ra: {str(e)}\n".encode())

        print(f"Dong ket noi voi {addr}")

