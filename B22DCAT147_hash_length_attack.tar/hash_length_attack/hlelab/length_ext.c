#include <stdio.h>
#include <arpa/inet.h>
#include <openssl/sha.h>

int main(int argc, const char *argv[]){
    int i;
    unsigned char buffer[SHA256_DIGEST_LENGTH];
    SHA256_CTX c;

    SHA256_Init(&c);

    for(i=0; i<64; i++) SHA256_Update(&c, "*", 1);

    c.h[0] = htole32(0x231a0b33);
    c.h[1] = htole32(0x62ae5a6f);
    c.h[2] = htole32(0xf845130f);
    c.h[3] = htole32(0x34c138f9);
    c.h[4] = htole32(0xe651bfe0);
    c.h[5] = htole32(0x02977a81);
    c.h[6] = htole32(0x61cb9d43);
    c.h[7] = htole32(0x6f53fd34);

    SHA256_Update(&c, "&download=secret.txt", 20);

    SHA256_Final(buffer, &c);

    for(i = 0; i < 32; i++) {
        printf("%02x", buffer[i]);
    }
    printf("\n");
    return 0;
}