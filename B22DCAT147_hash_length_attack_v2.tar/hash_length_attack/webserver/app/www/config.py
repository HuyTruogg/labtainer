import os


class Config(object):
    BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    LAB_HOME_DIR = os.path.join(BASE_DIR, 'LabHome')
    KEY_FILE_NAME = 'key.txt'
    DUMMY_FILE = 'secret.txt'
    DEFAULT_USER_ID = 1001
    DEFAULT_USER_KEY = '123456'
    KEY_FILE_DELIMITER = ':'
